package vjezbenedelja5;

import java.util.*; // import za arrayliste

public class Game {
 private Player player; // atribut plejer
 private ArrayList<Enemy> enemies = new ArrayList<>(); // lista neprijatelja
 private ArrayList<String> eventLog = new ArrayList<>(); // lista događaja

 public Game(Player player) { // konstruktor
     this.player = player; 
 }

 public void addEnemy(Enemy e) { // metoda za dodavanje neprijatelja u listu i zapisivanje događaja u logu
     enemies.add(e); 
     eventLog.add("ADDED: " + e);
 }

 public boolean checkCollision(Player p, Enemy e) {  // metoda za provjeru kolizije između plejera i neprijatelja
     return p.getX() < e.getX() + e.getWidth() &&
            p.getX() + p.getWidth() > e.getX() &&
            p.getY() < e.getY() + e.getHeight() &&
            p.getY() + p.getHeight() > e.getY();
 }

 public void decreaseHealth(Player p, Enemy e) {  // metoda za smanjenje zdravlja (hitpointova) plejera prilikom kolizije i zapisivanje događaja u logu
     int oldHP = p.getHealth();
     int newHP = Math.max(0, oldHP - e.getDamage());
     p.setHealth(newHP);
     eventLog.add("HIT: " + p.getName() + " by " + e.getType() + " for " + e.getDamage() +
                  " -> HP " + oldHP + " -> " + newHP);
 }

 public List<Enemy> findByType(String query) { // Metoda za pronalaženje neprijatelja po tipu (napravljeno da je case insensitive)
     List<Enemy> result = new ArrayList<>();
     for (Enemy e : enemies) {
         if (e.getType().toLowerCase().contains(query.toLowerCase())) {
             result.add(e);
         }
     }
     return result; // vraća listu neprijatelja koji odgovaraju upitu
 }

 public List<Enemy> collidingWithPlayer() { // Metoda za pronalaženje svih neprijatelja koji su u koliziji sa plejerom
     List<Enemy> result = new ArrayList<>();
     for (Enemy e : enemies) {
         if (checkCollision(player, e)) {
             result.add(e);
         }
     }
     return result;
 }

 public void resolveCollisions() {  // Metoda za rješavanje svih kolizija između plejera i neprijatelja
     for (Enemy e : collidingWithPlayer()) {
         decreaseHealth(player, e);
     }
 }

 public void printEventLog() { // Metoda za ispisivanje loga događaja
     System.out.println("=== EVENT LOG ===");
     for (String log : eventLog) {
         System.out.println(log);
     }
 }

 public void printEnemies() { // Metoda za ispisivanje svih neprijatelja u igri
     System.out.println("---ENEMIES---");
     for (Enemy e : enemies) {
         System.out.println(e);
     }
 }

 
 public static void main(String[] args) { //Ovdje testiramo radi li kod ispravno
     Player p = new Player("   player   one  ", 10, 5, 32, 32, 85); // kreiramo plejera
     Game game = new Game(p);

     Enemy e1 = new Enemy("Goblin", 12, 5, 16, 16, 20); //kreiramo neprijatelje
     Enemy e2 = new Enemy("Orc", 50, 50, 16, 16, 30);
     game.addEnemy(e1);
     game.addEnemy(e2);

     String enemyStr = "Goblin; 12,5;16x16;20"; // kreiramo neprijatelja iz stringa
     String[] parts = enemyStr.split(";");
     String type = parts[0].trim();
     String[] pos = parts[1].split(",");
     String[] size = parts[2].split("x");
     int dmg = Integer.parseInt(parts[3].trim());
     Enemy e3 = new Enemy(type,Integer.parseInt(pos[0].trim()),Integer.parseInt(pos[1].trim()),Integer.parseInt(size[0].trim()),Integer.parseInt(size[1].trim()),dmg);

     game.addEnemy(e3);// dodajemo neprijatelja u igru

     game.printEnemies();// ispisujemo neprijatelje

     System.out.println("\n=== Pretraži: 'gob' ===");// pretražujemo neprijatelje po tipu
     for (Enemy e : game.findByType("gob")) {
         System.out.println(e);// ispisujemo pronađene neprijatelje
     }

     System.out.println("\n=== PLAYER PRIJE COLLISION ===");// ispisujemo informacije o plejeru prije kolizije
     System.out.println(p);

     game.resolveCollisions();// rješavamo kolizije

     System.out.println("\n=== PLAYER NAKON COLLISION==="); // ispisujemo informacije o plejeru nakon kolizije
     System.out.println(p);

     game.printEventLog();// ispisujemo log događaja
 }
}
