package src;

import java.util.List;

public class Main {

    public static void main(String[] args) {

        RectangleCollider playerCollider = new RectangleCollider(10, 5, 32, 32);
        Player player = new Player(10, 5, playerCollider, " peTar petrovic ", 85);

        System.out.println("Player before collisions:");
        System.out.println(player);
        System.out.println();

        
        Game game = new Game(player);

        
        RectangleCollider enemy1Collider = new RectangleCollider(12, 5, 16, 16);
        MeleeEnemy enemy1 = new MeleeEnemy(12, 5, enemy1Collider, "Goblin", 20, 60);
        game.addEnemy(enemy1);

        
        String enemyStr = "Orc; 50,50;16x16;15;boss";
        Enemy enemy2 = Game.parseEnemy(enemyStr);
        game.addEnemy(enemy2);

        
        System.out.println("All enemies:");
        for (Enemy e : game.getEnemies()) {
            System.out.println(e);
        }
        System.out.println();

        
        List<Enemy> gobEnemies = game.findByType("gob");
        System.out.println("Enemies containing 'gob':");
        for (Enemy e : gobEnemies) {
            System.out.println(e);
        }
        System.out.println();

        
        System.out.println("Collisions with player:");
        for (Enemy e : game.getEnemies()) {
            boolean colliding = game.checkCollision(player, e);
            System.out.println(e.getDisplayName() + " colliding? " + colliding);
        }
        System.out.println();

        
        System.out.println("Player before resolveCollisions:");
        System.out.println(player);
        System.out.println();

        
        game.resolveCollisions();

        
        System.out.println("Player after resolveCollisions:");
        System.out.println(player);
        System.out.println();

        
        System.out.println("Event log:");
        for (String log : game.getEventLog()) {
            System.out.println(log);
        }
    }
}
