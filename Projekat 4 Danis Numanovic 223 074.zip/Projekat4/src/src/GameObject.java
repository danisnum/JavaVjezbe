package src;


public abstract class GameObject {
	private int x;
    private int y;
    private CollidableInterface collider;

    public GameObject(int x, int y, CollidableInterface collider) {
        setX(x);
        setY(y);
        setCollider(collider);
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public CollidableInterface getCollider() {
        return collider;
    }

    public void setCollider(CollidableInterface collider) {
        if (collider == null) {
            throw new IllegalArgumentException("Collider cannot be null.");
        }
        this.collider = collider;
    }

    
    public boolean intersects(GameObject other) {
        if (other == null) {
            throw new IllegalArgumentException("Other GameObject cannot be null.");
        }
        return this.collider.intersects(other.getCollider());

    }

    
    public abstract String getDisplayName();

    @Override
    public String toString() {
        return "GameObject at (" + x + ", " + y + ")";
    }

}
