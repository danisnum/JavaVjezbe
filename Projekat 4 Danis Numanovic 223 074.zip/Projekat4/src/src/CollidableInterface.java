package src;

public interface CollidableInterface {
    boolean intersects(CollidableInterface other);
}
