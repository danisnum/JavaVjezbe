package src;

public class CircleCollider implements CollidableInterface {

    private int x;       
    private int y;       
    private int radius;

    public CircleCollider(int x, int y, int radius) {
        if (radius <= 0) {
            throw new IllegalArgumentException("Radius must be positive.");
        }
        this.x = x;
        this.y = y;
        this.radius = radius;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getRadius() {
        return radius;
    }

    @Override
    public boolean intersects(CollidableInterface other) {

        
        if (other instanceof CircleCollider) {
            CircleCollider c = (CircleCollider) other;
            int dx = this.x - c.x;
            int dy = this.y - c.y;
            int distanceSquared = dx * dx + dy * dy;
            int radiusSum = this.radius + c.radius;
            return distanceSquared <= radiusSum * radiusSum;
        }

        
        if (other instanceof RectangleCollider) {
            RectangleCollider r = (RectangleCollider) other;

            
            int closestX = clamp(this.x, r.getX(), r.getX() + r.getWidth());
            int closestY = clamp(this.y, r.getY(), r.getY() + r.getHeight());

            int dx = this.x - closestX;
            int dy = this.y - closestY;

            return dx * dx + dy * dy <= radius * radius;
        }

        
        return false;
    }

    
    private int clamp(int value, int min, int max) {
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }

    @Override
    public String toString() {
        return "CircleCollider[x=" + x + ", y=" + y + ", radius=" + radius + "]";
    }
}
