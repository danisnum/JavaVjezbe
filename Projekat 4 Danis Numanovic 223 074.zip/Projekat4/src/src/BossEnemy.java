package src;

public class BossEnemy extends Enemy {

    public BossEnemy(int x, int y, CollidableInterface collider,
                     String type, int damage, int health) {
        super(x, y, collider, type, damage, health);
    }

    @Override
    public int getEffectiveDamage() {
        return super.getDamage() * 2;
    }

    @Override
    public String toString() {
        String sizeInfo = "";

        if (getCollider() instanceof RectangleCollider) {
            RectangleCollider r = (RectangleCollider) getCollider();
            sizeInfo = r.getWidth() + "x" + r.getHeight();
        } else if (getCollider() instanceof CircleCollider) {
            CircleCollider c = (CircleCollider) getCollider();
            sizeInfo = "radius=" + c.getRadius();
        }

        return "BossEnemy[" + getType() + "] @ (" + getX() + "," + getY() + ") " +
               sizeInfo + " DMG=" + getDamage() + "x2 HP=" + getHealth();
    }
}
