package src;

import java.util.ArrayList;
import java.util.List;

public class Game {

    private Player player;
    private List<Enemy> enemies;
    private List<String> eventLog;

    public Game(Player player) {
        if (player == null) {
            throw new IllegalArgumentException("Player cannot be null.");
        }
        this.player = player;
        this.enemies = new ArrayList<>();
        this.eventLog = new ArrayList<>();
    }

    public Player getPlayer() {
        return player;
    }

    public List<Enemy> getEnemies() {
        return enemies;
    }

    public List<String> getEventLog() {
        return eventLog;
    }

    public void addEnemy(Enemy e) {
        if (e == null) {
            throw new IllegalArgumentException("Enemy cannot be null.");
        }
        enemies.add(e);
        eventLog.add("Added enemy: " + e.getDisplayName());
    }

    
    public boolean checkCollision(Player p, Enemy e) {
        if (p == null || e == null) {
            throw new IllegalArgumentException("Player and Enemy cannot be null.");
        }
        return p.intersects(e);
    }

    
    public void decreaseHealth(Player p, Enemy e) {
        if (p == null || e == null) {
            throw new IllegalArgumentException("Player and Enemy cannot be null.");
        }
        int oldHP = p.getHealth();
        int newHP = Math.max(0, oldHP - e.getEffectiveDamage());
        p.setHealth(newHP);

        eventLog.add("HIT: Player by " + e.getDisplayName() +
                     " for " + e.getEffectiveDamage() +
                     " -> HP " + oldHP + " -> " + newHP);
    }

    
    public List<Enemy> findByType(String query) {
        List<Enemy> result = new ArrayList<>();
        if (query == null) return result;

        String q = query.toLowerCase();
        for (Enemy e : enemies) {
            if (e.getType().toLowerCase().contains(q)) {
                result.add(e);
            }
        }
        return result;
    }

    
    public List<Enemy> collidingWithPlayer() {
        List<Enemy> result = new ArrayList<>();
        for (Enemy e : enemies) {
            if (checkCollision(player, e)) {
                result.add(e);
            }
        }
        return result;
    }

    
    public void resolveCollisions() {
        for (Enemy e : enemies) {
            if (checkCollision(player, e)) {
                decreaseHealth(player, e);
            }
        }
    }

    
    public static Enemy parseEnemy(String line) {
        if (line == null) throw new IllegalArgumentException("Input line cannot be null.");

        try {
            // Format: "Goblin; 12,5;16x16;20;boss"
            String[] parts = line.split(";");
            if (parts.length != 5) {
                throw new IllegalArgumentException("Invalid enemy format: " + line);
            }

            String type = parts[0].trim();

            String[] pos = parts[1].trim().split(",");
            int x = Integer.parseInt(pos[0].trim());
            int y = Integer.parseInt(pos[1].trim());

            String[] size = parts[2].trim().split("x");
            int width = Integer.parseInt(size[0].trim());
            int height = Integer.parseInt(size[1].trim());

            int damage = Integer.parseInt(parts[3].trim());
            String category = parts[4].trim().toLowerCase();

            RectangleCollider collider = new RectangleCollider(x, y, width, height);

            if (category.equals("boss")) {
                return new BossEnemy(x, y, collider, type, damage, 100); // default health za boss
            } else {
                return new MeleeEnemy(x, y, collider, type, damage, 60); // default health
            }
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Invalid number format in line: " + line);
        }
    }
}
