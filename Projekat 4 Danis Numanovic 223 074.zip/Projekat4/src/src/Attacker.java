package src;


public interface Attacker {
    int getEffectiveDamage();
}
