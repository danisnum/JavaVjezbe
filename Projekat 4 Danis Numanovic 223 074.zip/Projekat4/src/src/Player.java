package src;

public class Player extends GameObject {

    private String name;
    private int health;

  
    public Player(int x, int y, CollidableInterface collider, String name, int health) {
        super(x, y, collider);
        setName(name);
        setHealth(health);
    }

    public String getName() {
        return name;
    }

   
    public void setName(String name) {
        if (name == null) {
            throw new IllegalArgumentException("Name cannot be null.");
        }

       
        name = name.trim().replaceAll("\\s+", " ");

        
        String[] words = name.split(" ");
        StringBuilder formatted = new StringBuilder();
        for (String word : words) {
            if (!word.isEmpty()) {
                formatted.append(Character.toUpperCase(word.charAt(0)));
                if (word.length() > 1) {
                    formatted.append(word.substring(1).toLowerCase());
                }
                formatted.append(" ");
            }
        }

        String result = formatted.toString().trim();

        if (result.isEmpty()) {
            throw new IllegalArgumentException("Name cannot be empty after formatting.");
        }

        this.name = result;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        if (health < 0 || health > 100) {
            throw new IllegalArgumentException("Health must be between 0 and 100.");
        }
        this.health = health;
    }

    @Override
    public String getDisplayName() {
        return name;
    }

    @Override
    public String toString() {
        String sizeInfo = "";

       
        if (getCollider() instanceof RectangleCollider) {
            RectangleCollider r = (RectangleCollider) getCollider();
            sizeInfo = r.getWidth() + "x" + r.getHeight();
        }
        
        else if (getCollider() instanceof CircleCollider) {
            CircleCollider c = (CircleCollider) getCollider();
            sizeInfo = "radius=" + c.getRadius();
        }

        return "Player[" + name + "] @ (" + getX() + "," + getY() + ") " +
               sizeInfo + " HP=" + health;
    }
}
