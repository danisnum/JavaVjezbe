package src;

public class BossEnemy extends Enemy{
	
	private String specialAttack;
	
	public BossEnemy(int x, int y, int width, int height, int damage, String specialAttack) {
		super(x, y, width, height, specialAttack, damage, damage);
		setSpecialAttack(specialAttack);
	}

	public String getSpecialAttack() {
		return specialAttack;
	}

	public void setSpecialAttack(String specialAttack) {
		this.specialAttack = specialAttack;
	}
	
	@Override
	public String toString() {
	    return String.format("BossEnemy @ (%d,%d) %dx%d Damage=%d SpecialAttack=%s",
	            getX(), getY(), getWidth(), getHeight(), getDamage(), specialAttack);
	}

}
