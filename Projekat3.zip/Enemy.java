package src;

public class Enemy extends GameObject {

	private String tipNeprijatelja;
	private int damage;
	private int healthNeprijatelja;
	public Enemy(int x, int y, int width, int height, String tipNeprijatelja, int damage, int healthNeprijatelja) {
		super(x, y, width, height);
		setTipNeprijatelja(tipNeprijatelja);
		setDamage(damage);
		setHealthNeprijatelja(healthNeprijatelja);
	}
	public String getTipNeprijatelja() {
		return tipNeprijatelja;
	}
	public void setTipNeprijatelja(String tipNeprijatelja) {
		this.tipNeprijatelja = tipNeprijatelja;
	}
	public int getDamage() {
		return damage;
	}
	public void setDamage(int damage) {
		if(damage < 0) {
			damage = 0;
		}
		if(damage > 100) {
			damage = 100;
		}
		
		this.damage = damage;
	}
	public int getHealthNeprijatelja() {
		return healthNeprijatelja;
	}
	public void setHealthNeprijatelja(int healthNeprijatelja) {
		if(healthNeprijatelja < 0) {
			healthNeprijatelja = 0;
		}
		if(healthNeprijatelja > 100) {
			healthNeprijatelja = 100;
		}
		this.healthNeprijatelja = healthNeprijatelja;
	}
	
	@Override
	public String toString() {
	    return String.format("Player[%s] @ (%d,%d) %dx%d HP=%d",
	            tipNeprijatelja, getX(), getY(), getWidth(), getHeight(), healthNeprijatelja);
	}
	
	
}
