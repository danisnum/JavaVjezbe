package src;

public class MeleeEnemy extends Enemy{
	
	private double attackRange;

	public MeleeEnemy(int x, int y, int width, int height, String tipNeprijatelja, int damage, int healthNeprijatelja, double attackRange) {
		super(x, y, width, height, tipNeprijatelja, damage, healthNeprijatelja);
		setAttackRange(attackRange);
	}

	public double getAttackRange() {
		return attackRange;
	}

	public void setAttackRange(double attackRange) {
		if(attackRange < 0) {
			attackRange = 0;
		}
		this.attackRange = attackRange;
	}

	@Override
	public String toString() {
		return String.format("MeleeEnemy[%s] @ (%d,%d) %dx%d HP=%d AttackRange=%.2f",
				getTipNeprijatelja(), getX(), getY(), getWidth(), getHeight(), getHealthNeprijatelja(), attackRange);
	}
	
	
}
