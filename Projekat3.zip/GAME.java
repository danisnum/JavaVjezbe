package src;

import java.util.ArrayList;
import java.util.List;  					// Danis Numanovic 23/074 i Petar Raicevic 22/053

public class GAME {

    private static List<Enemy> enemies = new ArrayList<>();
    private static List<String> eventLog = new ArrayList<>();
    private static Player player;

    public static void main(String[] args) {

       
        player = new Player(10, 5, 32, 32, "Petar Petrović", 85);

       
        Enemy e1 = new Enemy(10, 5, 32, 32, "Goblin", 20, 60);
        Enemy e2 = new MeleeEnemy(50, 20, 32, 32, "Ork", 15, 50, 1.5);
        Enemy e3 = new BossEnemy(10, 5, 64, 64, 40, "Fireball");

       
        addEnemy(e1);
        addEnemy(e2);
        addEnemy(e3);

       
        System.out.println("Svi neprijatelji:");
        for (Enemy e : enemies) {
            System.out.println(e);
        }

       
        resolveCollisions();

       
        System.out.println("\nEvent log:");
        for (String event : eventLog) {
            System.out.println(event);
        }

       
        System.out.println("\nNeprijatelji tipa 'Goblin':");
        List<Enemy> goblins = findByType("goblin");
        for (Enemy g : goblins) {
            System.out.println(g);
        }
    }

        public static void addEnemy(Enemy e) {
        enemies.add(e);
        eventLog.add("ADD: " + e.getTipNeprijatelja());
    }

    
      public static boolean checkCollision(Player p, Enemy e) {
        return p.intersects(e);
    }

    
    public static void decreaseHealth(Player p, Enemy e) {
        int damage = e.getDamage();

        if (e instanceof BossEnemy) {
            damage *= 2;
        }

        int oldHp = p.getHealth();
        int newHp = oldHp - damage;
        if (newHp < 0) newHp = 0;
        p.setHealth(newHp);

        eventLog.add(String.format("HIT: Player by %s for %d -> HP %d -> %d",
                e.getTipNeprijatelja(), damage, oldHp, newHp));
    }

    
    public static List<Enemy> findByType(String query) {
        List<Enemy> result = new ArrayList<>();
        String q = query.toLowerCase();
        for (Enemy e : enemies) {
            if (e.getTipNeprijatelja().toLowerCase().contains(q)) {
                result.add(e);
            }
        }
        return result;
    }

    
    public static List<Enemy> collidingWithPlayer() {
        List<Enemy> colliding = new ArrayList<>();
        for (Enemy e : enemies) {
            if (checkCollision(player, e)) {
                colliding.add(e);
            }
        }
        return colliding;
    }

    
    public static void resolveCollisions() {
        for (Enemy e : enemies) {
            if (checkCollision(player, e)) {
                decreaseHealth(player, e);
            }
        }
    }
}
