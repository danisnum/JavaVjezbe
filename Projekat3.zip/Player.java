package src;

public class Player extends GameObject{

	private String name;
	private int health;
	public Player(int x, int y, int width, int height, String name, int health) {
		super(x, y, width, height);
		setName(name);
		setHealth(health);
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getHealth() {
		return health;
	}
	public void setHealth(int health) {
		if(health < 0) {
			health = 0;
		}
		if(health > 100) {
			health = 100;
		}
		this.health = health;
	}
	
	@Override
	public String toString() {
	    return String.format("Player[%s] @ (%d,%d) %dx%d HP=%d",
	            name, getX(), getY(), getWidth(), getHeight(), health);
	}

	
}
