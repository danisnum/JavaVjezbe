package vjezbe06_11_2;

public class ObracunPlate {
    private int mjesec;        
    private int godina;
    private zaposleni zaposleni; 
    private double iznos;      
    private String napomena;   

    public ObracunPlate(int mjesec, int godina, zaposleni zaposleni, double iznos, String napomena) {
        this.mjesec = mjesec;
        this.godina = godina;
        this.zaposleni = zaposleni;
        this.iznos = iznos;
        this.napomena = napomena;
    }

    
 
    public int mjesec()         { return mjesec; }
    public int godina()         { return godina; }
    public zaposleni zaposleni() { return zaposleni; }
    public double iznos()       { return iznos; }
    public String napomena()    { return napomena; }

    
    public void mjesec(int m)         { this.mjesec = m; }
    public void godina(int g)         { this.godina = g; }
    public void zaposleni(zaposleni z) { this.zaposleni = z; }
    public void iznos(double i)       { this.iznos = i; }
    public void napomena(String n)    { this.napomena = n; }


    @Override
    public String toString() {
        return String.format("%02d/%d - %s %s: %.2f EUR (%s)",
                mjesec, godina,
                zaposleni.getIme(), zaposleni.getPrezime(),
                iznos,
                napomena.isEmpty() ? "-" : napomena);
    }
}
