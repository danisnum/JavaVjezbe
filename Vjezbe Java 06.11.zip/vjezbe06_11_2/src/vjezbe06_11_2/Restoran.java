package vjezbe06_11_2;

import java.util.ArrayList;

public class Restoran {
    private String naziv;
    private String adresa;
    private String PIB;
    private ArrayList<zaposleni> listaZaposlenih;

    public Restoran(String naziv, String adresa, String PIB) {
        this.naziv = naziv;
        this.adresa = adresa;
        this.PIB = PIB;
        this.listaZaposlenih = new ArrayList<>();
    }

    public void dodajZaposlenog(zaposleni z) {
        listaZaposlenih.add(z);
    }

    public void ukloniZaposlenog(int ID) {
        listaZaposlenih.removeIf(z -> z.getID() == ID);
    }

    public void mjesecniObracun() {
        System.out.printf("%-5s %-10s %-10s %-10s %-10s %-10s %-10s%n",
                          "ID", "Ime", "Prezime", "Tip", "Sati", "Prek/Bonus", "Plata");
        

        for (zaposleni z : listaZaposlenih) {
            System.out.printf("%-5d %-10s %-10s %-10s %-10d %-10s %-10.2f%n",
                              z.getID(), z.getIme(), z.getPrezime(),
                              z.getClass().getSimpleName(),
                              z.getBrojSati(), z.getDodatak(), z.obracunajPlatu());
        }
    }
    
    public double ukupniTrosakPlata() {
        double ukupno = 0;
        for (zaposleni z : listaZaposlenih) {
            ukupno += z.obracunajPlatu();
        }
        return ukupno;
    }
    
    private ArrayList<ObracunPlate> istorijaPlata = new ArrayList<>();

    public void generisiObracune(int mjesec, int godina) {
        for (zaposleni z : listaZaposlenih) {
            double plata = z.obracunajPlatu();    
            String napomena = z.getDodatak().equals("-") ? "" : z.getDodatak();
            ObracunPlate obracun = new ObracunPlate(mjesec, godina, z, plata, napomena);
            istorijaPlata.add(obracun);
        }
    }

    
    public void ispisiIstoriju() {
        for (ObracunPlate o : istorijaPlata) {
            System.out.println(o);
        }
    }


}
