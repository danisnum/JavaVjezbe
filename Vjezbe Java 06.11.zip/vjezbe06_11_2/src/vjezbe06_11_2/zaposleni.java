package vjezbe06_11_2;

public abstract class zaposleni {
    private int ID;
    private String ime;
    private String prezime;
    private int satnica;
    private int brojSati;

    public zaposleni(int ID, String ime, String prezime, int satnica, int brojSati) {
        this.ID = ID;
        this.ime = ime;
        this.prezime = prezime;
        this.satnica = satnica;
        this.brojSati = brojSati;
    }
    
    public void setBrojSati(int brojSati) {
        this.brojSati = brojSati;
    }


    public int getID() { return ID; }
    public String getIme() { return ime; }
    public String getPrezime() { return prezime; }
    public int getSatnica() { return satnica; }
    public int getBrojSati() { return brojSati; }

    
    public abstract double obracunajPlatu();

    
    public String getDodatak() {
        return "-";
    }
}
