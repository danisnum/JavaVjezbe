package vjezbe06_11_2;

public class konobar extends zaposleni {

    public konobar(int ID, String ime, String prezime, int satnica, int brojSati) {
        super(ID, ime, prezime, satnica, brojSati);
    }

    @Override
    public double obracunajPlatu() {
        int regularni = Math.min(getBrojSati(), 40);
        int prekovremeni = Math.max(getBrojSati() - 40, 0);
        double sedmica = regularni * getSatnica() + prekovremeni * getSatnica() * 1.2;
        return sedmica * 4;
    }

    @Override
    public String getDodatak() {
        int prekovremeni = Math.max(getBrojSati() - 40, 0);
        return prekovremeni > 0 ? String.valueOf(prekovremeni) : "-";
    }
}
