package vjezbe06_11_2;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        
        Restoran restoran = new Restoran("Gurmanski Raj", "Podgorica, CG", "123456789");

        
        konobar konobar = new konobar(1, "Jovan", "Nedic", 10, 45);
        kuvar kuvar = new kuvar(2, "Semir", "Bralic", 12, 40);         
        menadzer menadzer = new menadzer(3, "Petar", "Raicevic", 15, 38, 200); 
        konobar konobar2 = new konobar(4, "Omar", "Dizdarevic", 11, 42); 
        kuvar kuvar2 = new kuvar(5, "Emir", "Balijagic", 13, 40);       

        
        restoran.dodajZaposlenog(konobar);
        restoran.dodajZaposlenog(kuvar);
        restoran.dodajZaposlenog(menadzer);
        restoran.dodajZaposlenog(konobar2);
        restoran.dodajZaposlenog(kuvar2);

       
        int mjesec = 11;
        int godina = 2025;
        restoran.generisiObracune(mjesec, godina);

       
        System.out.println("Mjesecni obracun plata");
        restoran.mjesecniObracun();

       
        double ukupno = restoran.ukupniTrosakPlata();
        System.out.printf("%nUkupan trosak plata za %02d/%d: %.2f EUR%n", mjesec, godina, ukupno);

       
        System.out.println("\n Istorija obracuna plata");
        restoran.ispisiIstoriju();
    }
}
