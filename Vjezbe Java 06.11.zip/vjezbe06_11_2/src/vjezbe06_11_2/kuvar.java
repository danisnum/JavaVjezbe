package vjezbe06_11_2;

public class kuvar extends zaposleni {

    public kuvar(int ID, String ime, String prezime, int satnica, int brojSati) {
        super(ID, ime, prezime, satnica, brojSati);
    }

    @Override
    public double obracunajPlatu() {
        return 1500 + 4 * getBrojSati() * getSatnica();
    }
}
