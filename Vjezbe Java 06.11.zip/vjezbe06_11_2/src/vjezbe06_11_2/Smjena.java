package vjezbe06_11_2;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Duration;
import java.util.ArrayList;

public class Smjena {
    private LocalDate datum;
    private LocalTime pocetak;
    private LocalTime kraj;
    private String tip; 
    private ArrayList<zaposleni> zaposleniUSmjeni;

    public Smjena(LocalDate datum, LocalTime pocetak, LocalTime kraj, String tip) {
        this.datum = datum;
        this.pocetak = pocetak;
        this.kraj = kraj;
        this.tip = tip;
        this.zaposleniUSmjeni = new ArrayList<>();
    }

    public void dodajZaposlenog(zaposleni z) {
        zaposleniUSmjeni.add(z);
    }

    public void ukloniZaposlenog(zaposleni z) {
        zaposleniUSmjeni.remove(z);
    }

    
    public int trajanjeUSatima() {
        Duration trajanje = Duration.between(pocetak, kraj);
        return (int) trajanje.toHours(); 
    }

    
    public void azurirajBrojSatiZaposlenih() {
        int sati = trajanjeUSatima();
        for (zaposleni z : zaposleniUSmjeni) {
            z.setBrojSati(z.getBrojSati() + sati);
        }
    }

    public String getTip() {
        return tip;
    }
}
