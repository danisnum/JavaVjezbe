package vjezbe06_11_2;

public class menadzer extends zaposleni {
    private double bonus;

    public menadzer(int ID, String ime, String prezime, int satnica, int brojSati, double bonus) {
        super(ID, ime, prezime, satnica, brojSati);
        this.bonus = bonus;
    }

    public double getBonus() { return bonus; }

    @Override
    public double obracunajPlatu() {
        return 1300 + 4 * getBrojSati() * getSatnica() + bonus;
    }

    @Override
    public String getDodatak() {
        return bonus > 0 ? String.valueOf(bonus) : "-";
    }
}
