package vjezbe06_11;

import java.util.Scanner;
import java.util.ArrayList;

public class MAIN {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<EProizvodi> proizvodi = new ArrayList<>();

        boolean izlaz = false;

        while (!izlaz) {
            System.out.println("\nOdaberite opciju:");
            System.out.println("1. Unos uredjaja");
            System.out.println("2. Pregled svih uredjaja s maloprodajnom cijenom");
            System.out.println("3. Pregled odredjenog tipa uredjaja");
            

            System.out.print("Unesite opciju: ");
            int opcija = sc.nextInt();
            sc.nextLine(); 

            
            if (opcija == 1) { 
                System.out.print("Unesite opis uredjaja: ");
                String opis = sc.nextLine();

                System.out.print("Unesite sifru uredjaja: ");
                String sifra = sc.nextLine();

                System.out.print("Unesite uvoznu cijenu: ");
                double cijena = sc.nextDouble();
                sc.nextLine(); 

                String tip = sifra.substring(0, 2).toUpperCase();

                
                if (tip.equals("RA")) {
                    System.out.print("Unesite procesor: ");
                    String procesor = sc.nextLine();
                    System.out.print("Unesite memoriju (GB): ");
                    int memorija = sc.nextInt();
                    sc.nextLine();
                    proizvodi.add(new Racunari(opis, sifra, cijena, procesor, memorija));
                } else if (tip.equals("TE")) {
                    System.out.print("Unesite operativni sistem: ");
                    String operativniSistem = sc.nextLine();
                    System.out.print("Unesite velicinu ekrana (inč): ");
                    double ekran = sc.nextDouble();
                    sc.nextLine();
                    proizvodi.add(new Telefoni(opis, sifra, cijena, operativniSistem, ekran));
                } else if (tip.equals("TV")) {
                    System.out.print("Unesite velicinu ekrana (inč): ");
                    double velicinaEkrana = sc.nextDouble();
                    
                    proizvodi.add(new TV(opis, sifra, cijena, velicinaEkrana));
                } else {
                    System.out.println("Nepoznat tip uredjaja, unos nije moguć.");
                }

            } else if (opcija == 2) { 
                System.out.println("\nSvi proizvodi:");
                for (EProizvodi p : proizvodi) {
                    System.out.println("- " + p.getOpis() + " (" + p.getSifra() + ") cijena: " + p.maloprodajnaCijena(p.getUvoznaCijena()));
                }

            } else if (opcija == 3) { 
                System.out.print("Unesite tip uredjaja (Racunari / Telefoni / TV): ");
                String trazeniTip = sc.nextLine();
                System.out.println("\nProizvodi tipa: " + trazeniTip);
                for (EProizvodi p : proizvodi) {
                    if (p.klasifikujProizvod().equalsIgnoreCase(trazeniTip)) {
                        System.out.println("- " + p.getOpis() + " (" + p.getSifra() + ") cijena: " + p.maloprodajnaCijena(p.getUvoznaCijena()));
                    }
                }

            }
        }

        
    }
}
