package vjezbe06_11;

public class TV extends EProizvodi {
	
	private double VelicinaEkrana;
	
	public TV(String opis, String sifra, double uvoznaCijena, double velicinaEkrana) {
		super(opis, sifra, uvoznaCijena);
		VelicinaEkrana = velicinaEkrana;
	}

	public double getVelicinaEkrana() {
		return VelicinaEkrana;
	}

	public void setVelicinaEkrana(double velicinaEkrana) {
		VelicinaEkrana = velicinaEkrana;
	}
	
	@Override
	public double maloprodajnaCijena(double uvoznaCijena) {
	    double basePrice = super.maloprodajnaCijena(uvoznaCijena);
	    if (getVelicinaEkrana() > 65.0) {
	        return basePrice * 1.15; 
	    }
	    return basePrice * 1.05; 
	}
	
}
