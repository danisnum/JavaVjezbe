package vjezbe06_11;

public class EProizvodi {

	private String opis;
	private String sifra;
	private double uvoznaCijena;
	public EProizvodi(String opis, String sifra, double uvoznaCijena) {
		this.opis = opis;
		this.sifra = sifra;
		this.uvoznaCijena = uvoznaCijena;
	}
	public String getOpis() {
		return opis;
	}
	public void setOpis(String opis) {
		this.opis = opis;
	}
	public String getSifra() {
		return sifra;
	}
	public void setSifra(String sifra) {
		this.sifra = sifra;
	}
	public double getUvoznaCijena() {
		return uvoznaCijena;
	}
	public void setUvoznaCijena(double uvoznaCijena) {
		this.uvoznaCijena = uvoznaCijena;
	}
	
	
	
	public double maloprodajnaCijena(double uvoznaCijena) {
		return uvoznaCijena * 1.05;
	}
	
	 public String klasifikujProizvod() {
	        if (sifra == null || sifra.length() < 2) {
	            return "Nepoznat tip";
	        }

	        String prefix = sifra.substring(0, 2).toUpperCase();

	        if (prefix.equals("RA")) {
	            return "Racunari";
	        } else if (prefix.equals("TE")) {
	            return "Telefoni";
	        } else if (prefix.equals("TV")) {
	            return "TV";
	        } else {
	            return "Nepoznat tip";
	        }
	    }
	
	 public static void stampajProizvodePoTipu(EProizvodi[] proizvodi, String tip) {
		    System.out.println("Proizvodi tipa: " + tip);

		    for (EProizvodi p : proizvodi) {
		        if (p != null && p.klasifikujProizvod().equalsIgnoreCase(tip)) {
		            System.out.println("- " + p.getOpis() + " (" + p.getSifra() + ") cijena: " + p.maloprodajnaCijena(p.getUvoznaCijena()));
		        }
		    }
		}

}
