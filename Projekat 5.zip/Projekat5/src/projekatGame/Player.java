package projekatGame;


public class Player extends GameObject {
    private final String name;
    private int health; // 0..100

    public Player(String name, int x, int y, Collidable collider, int health) {
        super(x, y, collider);
        if (name == null) throw new IllegalArgumentException("name cannot be null");
        String processed = normalizeName(name);
        if (processed.isEmpty()) throw new IllegalArgumentException("name empty after processing");
        this.name = processed;
        setHealth(health);
    }

    private static String normalizeName(String s) {
        String t = s.trim();
        if (t.isEmpty()) return "";
        return t.substring(0,1).toUpperCase() + (t.length() > 1 ? t.substring(1) : "");
    }

    public String getName() { return name; }

    public int getHealth() { return health; }
    public void setHealth(int health) {
        if (health < 0 || health > 100) throw new IllegalArgumentException("health must be between 0 and 100");
        this.health = health;
    }

    @Override
    public String getDisplayName() {
        return name;
    }

    @Override
    public String toString() {
        return String.format("Player[name=%s,health=%d] %s", name, health, super.toString());
    }
}
