package projekatGame;

/**
 * Krug kao kolajder. Tretira se da su x,y koordinate centra kruga.
 */
public class CircleCollider implements Collidable {
    private int x;
    private int y;
    private final int radius;

    public CircleCollider(int x, int y, int radius) {
        if (radius <= 0) throw new IllegalArgumentException("Radius must be > 0");
        if (x < 0 || y < 0) throw new IllegalArgumentException("Position must be >= 0");
        this.x = x;
        this.y = y;
        this.radius = radius;
    }

    // Bez pozicije
    public CircleCollider(int radius) {
        this(0, 0, radius);
    }

    @Override
    public void setPosition(int x, int y) {
        if (x < 0 || y < 0) throw new IllegalArgumentException("Position must be >= 0");
        this.x = x;
        this.y = y;
    }

    @Override public int getX() { return x; }
    @Override public int getY() { return y; }
    public int getRadius() { return radius; }

    @Override
    public boolean intersects(Collidable other) {
        if (other instanceof CircleCollider) {
            CircleCollider c = (CircleCollider) other;
            long dx = (long) this.x - c.x;
            long dy = (long) this.y - c.y;
            long rsum = (long) this.radius + c.radius;
            return dx*dx + dy*dy <= rsum*rsum;
        } else if (other instanceof RectangleCollider) {
            RectangleCollider rect = (RectangleCollider) other;
            int rectX = rect.getX();
            int rectY = rect.getY();
            int rectW = rect.getWidth();
            int rectH = rect.getHeight();

            int closestX = clamp(this.x, rectX, rectX + rectW);
            int closestY = clamp(this.y, rectY, rectY + rectH);

            long dx = (long) this.x - closestX;
            long dy = (long) this.y - closestY;
            return dx*dx + dy*dy <= (long) radius * radius;
        } else {
            throw new IllegalArgumentException("Unsupported Collidable: " + other.getClass());
        }
    }

    private static int clamp(int val, int min, int max) {
        if (val < min) return min;
        if (val > max) return max;
        return val;
    }

    @Override
    public String toString() {
        return String.format("Circle[x=%d,y=%d,r=%d]", x, y, radius);
    }
}
