package projekatGame;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;


public class Game {
    private Player player;
    private final List<Enemy> enemies = new ArrayList<>();
    private final List<String> log = new ArrayList<>();

    public Game() {}

    public Player getPlayer() { return player; }
    public void setPlayer(Player p) { this.player = p; }

    public List<Enemy> getEnemies() { return Collections.unmodifiableList(enemies); }
    public List<String> getLog() { return Collections.unmodifiableList(log); }

    public boolean checkCollision(Player p, Enemy e) {
        if (p == null || e == null) return false;
        return p.intersects(e);
    }

    public void decreaseHealth(Player p, Enemy e) {
        if (p == null || e == null) return;
        int dmg = e.getEffectiveDamage();
        int old = p.getHealth();
        int neu = Math.max(0, old - dmg);
        p.setHealth(neu);
        log.add(String.format("Enemy '%s' dealt %d damage to player '%s'. Health: %d -> %d",
                e.getType(), dmg, p.getName(), old, neu));
    }

    public void addEnemy(Enemy e) {
        enemies.add(e);
        log.add("Added enemy: " + e.toString());
    }

    public List<Enemy> findByType(String query) {
        if (query == null) return Collections.emptyList();
        String q = query.toLowerCase();
        List<Enemy> out = new ArrayList<>();
        for (Enemy e : enemies) {
            if (e.getType().toLowerCase().contains(q)) out.add(e);
        }
        return out;
    }

    public List<Enemy> collidingWithPlayer() {
        List<Enemy> out = new ArrayList<>();
        if (player == null) return out;
        for (Enemy e : enemies) {
            if (checkCollision(player, e)) out.add(e);
        }
        return out;
    }

   
    public void resolveCollisions() {
        if (player == null) return;
        for (Enemy e : enemies) {
            if (checkCollision(player, e) && player.getHealth() > 0) {
                decreaseHealth(player, e);
            }
        }
    }

    
    public static List<Enemy> loadEnemiesFromCSV(String filePath) throws IOException {
        List<Enemy> result = new ArrayList<>();
        List<String> lines = Files.readAllLines(Paths.get(filePath));
        int lineno = 0;
        for (String raw : lines) {
            lineno++;
            String line = raw.trim();
            if (line.isEmpty() || line.startsWith("#") || line.toLowerCase().startsWith("type,")) continue;
            String[] parts = line.split(",", -1);
            if (parts.length < 9) throw new IllegalArgumentException("Invalid CSV format at line " + lineno + ": " + line);

            String type = parts[0].trim();
            String clazz = parts[1].trim().toLowerCase();
            int x = parseIntField(parts[2].trim(), "x", lineno);
            int y = parseIntField(parts[3].trim(), "y", lineno);
            String shape = parts[4].trim().toLowerCase();
            String p1 = parts[5].trim();
            String p2 = parts[6].trim();
            int damage = parseIntField(parts[7].trim(), "damage", lineno);
            int health = parseIntField(parts[8].trim(), "health", lineno);

            Collidable collider;
            if ("rect".equals(shape)) {
                int w = parseIntField(p1, "width", lineno);
                int h = parseIntField(p2, "height", lineno);
                collider = new RectangleCollider(x, y, w, h);
            } else if ("circle".equals(shape)) {
                int r = parseIntField(p1, "radius", lineno);
                collider = new CircleCollider(x, y, r);
            } else {
                throw new IllegalArgumentException("Unknown shape '" + shape + "' at line " + lineno);
            }

            Enemy e;
            if ("melee".equals(clazz)) {
                e = new MeleeEnemy(type, x, y, collider, damage, health);
            } else if ("boss".equals(clazz)) {
                e = new BossEnemy(type, x, y, collider, damage, health);
            } else {
                throw new IllegalArgumentException("Unknown class '" + clazz + "' at line " + lineno);
            }

            result.add(e);
        }
        return result;
    }

    private static int parseIntField(String s, String fieldName, int lineno) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Invalid integer for " + fieldName + " at line " + lineno + ": '" + s + "'");
        }
    }
}
