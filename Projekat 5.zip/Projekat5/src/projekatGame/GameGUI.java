package projekatGame;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.List;


public class GameGUI {
    private final JFrame frame = new JFrame("Projekat 5 - Game GUI");
    private final JTextField tfName = new JTextField(15);
    private final JTextField tfHealth = new JTextField("100", 4);
    private final JTextField tfX = new JTextField("0", 4);
    private final JTextField tfY = new JTextField("0", 4);
    private final JRadioButton rbRect = new JRadioButton("Rectangle (32x32)", true);
    private final JRadioButton rbCircle = new JRadioButton("Circle (r=16)");
    private final JButton btnChooseCSV = new JButton("Izaberi enemies.csv...");
    private final JLabel lblCSV = new JLabel("nijedan fajl");
    private File selectedCSV = null;
    private final JTextArea taOutput = new JTextArea(20, 60);

    public GameGUI() { build(); }

    private void build() {
        JPanel p = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(4,4,4,4);
        c.anchor = GridBagConstraints.WEST;

        c.gridx = 0; c.gridy = 0; p.add(new JLabel("Ime:"), c);
        c.gridx = 1; p.add(tfName, c);

        c.gridx = 0; c.gridy = 1; p.add(new JLabel("Health (0-100):"), c);
        c.gridx = 1; p.add(tfHealth, c);

        c.gridx = 0; c.gridy = 2; p.add(new JLabel("X:"), c);
        c.gridx = 1; p.add(tfX, c);
        c.gridx = 2; p.add(new JLabel("Y:"), c);
        c.gridx = 3; p.add(tfY, c);

        c.gridx = 0; c.gridy = 3; p.add(new JLabel("Collider:"), c);
        c.gridx = 1;
        ButtonGroup bg = new ButtonGroup();
        bg.add(rbRect); bg.add(rbCircle);
        JPanel shapes = new JPanel(new FlowLayout(FlowLayout.LEFT,0,0));
        shapes.add(rbRect); shapes.add(rbCircle);
        p.add(shapes, c);

        c.gridx = 0; c.gridy = 4; p.add(btnChooseCSV, c);
        c.gridx = 1; p.add(lblCSV, c);

        JButton btnRun = new JButton("Pokreni igru");
        c.gridx = 0; c.gridy = 5; p.add(btnRun, c);

        taOutput.setEditable(false);
        JScrollPane sp = new JScrollPane(taOutput);

        frame.getContentPane().setLayout(new BorderLayout());
        frame.getContentPane().add(p, BorderLayout.NORTH);
        frame.getContentPane().add(sp, BorderLayout.CENTER);

        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        btnChooseCSV.addActionListener(e -> {
            JFileChooser fc = new JFileChooser();
            if (fc.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
                selectedCSV = fc.getSelectedFile();
                lblCSV.setText(selectedCSV.getName());
            }
        });

        btnRun.addActionListener(e -> onRun());
    }

    private void onRun() {
        try {
            String name = tfName.getText();
            int health = Integer.parseInt(tfHealth.getText().trim());
            int x = Integer.parseInt(tfX.getText().trim());
            int y = Integer.parseInt(tfY.getText().trim());

            Collidable collider = rbRect.isSelected()
                    ? new RectangleCollider(32, 32)   
                    : new CircleCollider(16);

            if (selectedCSV == null) {
                JOptionPane.showMessageDialog(frame, "Izaberi CSV fajl sa neprijateljima.", "Greska", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Player p = new Player(name, x, y, collider, health);
            Game game = new Game();
            game.setPlayer(p);

            
            List<Enemy> enemies = Game.loadEnemiesFromCSV(selectedCSV.getAbsolutePath());
            for (Enemy e : enemies) game.addEnemy(e);

            
            StringBuilder sb = new StringBuilder();
            sb.append("POČETNO STANJE\n");
            sb.append(p.toString()).append("\n\n");
            sb.append("Učitani neprijatelji:\n");
            for (Enemy e : game.getEnemies()) sb.append(" - ").append(e.toString()).append("\n");
            sb.append("\nResolving collisions...\n");

            
            game.resolveCollisions();

            sb.append("\nNakon provjere kolizija:\n");
            sb.append("Player: ").append(game.getPlayer().toString()).append("\n\n");
            sb.append("Neprijatelji u koliziji sa igračem:\n");
            for (Enemy ce : game.collidingWithPlayer()) sb.append(" * ").append(ce.toString()).append("\n");
            sb.append("\nLog događaja:\n");
            for (String log : game.getLog()) sb.append(log).append("\n");

            taOutput.setText(sb.toString());

            
            if (game.getPlayer().getHealth() <= 0) {
                JOptionPane.showMessageDialog(frame, "Igrač je poražen!", "Kraj igre", JOptionPane.INFORMATION_MESSAGE);
            } else {
                boolean allEnemiesDead = true;
                for (Enemy e : game.getEnemies()) {
                    if (e.getHealth() > 0) { allEnemiesDead = false; break; }
                }
                if (allEnemiesDead) {
                    JOptionPane.showMessageDialog(frame, "Svi nepriijatelji su porazeni", "Kraj igre", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(frame, "Igra zavrsena. Pogledaj rezultat", "Rezultat", JOptionPane.INFORMATION_MESSAGE);
                }
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Polja za brojeve moraju biti cjelobrojna.", "Greska", JOptionPane.ERROR_MESSAGE);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(frame, "Neispravni podaci: " + ex.getMessage(), "Greska", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "Greška: " + ex.getMessage(), "Greska", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    public void show() {
        SwingUtilities.invokeLater(() -> frame.setVisible(true));
    }
}
