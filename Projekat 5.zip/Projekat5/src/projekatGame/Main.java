package projekatGame;


public class Main {
    public static void main(String[] args) {
        new GameGUI().show();
    }
}
