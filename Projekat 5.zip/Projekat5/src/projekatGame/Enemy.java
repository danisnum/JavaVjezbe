package projekatGame;


public class Enemy extends GameObject implements Attacker {
    private final String type;
    private int damage; 
    private int health; 

    public Enemy(String type, int x, int y, Collidable collider, int damage, int health) {
        super(x, y, collider);
        if (type == null || type.trim().isEmpty()) throw new IllegalArgumentException("type must not be empty");
        this.type = type.trim();
        setDamage(damage);
        setHealth(health);
    }

    public String getType() { return type; }

    public int getDamage() { return damage; }
    public void setDamage(int damage) {
        if (damage < 0 || damage > 100) throw new IllegalArgumentException("damage must be 0..100");
        this.damage = damage;
    }

    public int getHealth() { return health; }
    public void setHealth(int health) {
        if (health < 0 || health > 100) throw new IllegalArgumentException("health must be 0..100");
        this.health = health;
    }

    @Override
    public int getEffectiveDamage() {
        return damage;
    }

    @Override
    public String getDisplayName() {
        return type;
    }

    @Override
    public String toString() {
        return String.format("Enemy[type=%s,dmg=%d,hp=%d] %s", type, damage, health, super.toString());
    }
}
