package projekatGame;

public interface Attacker {
    int getEffectiveDamage();
}
