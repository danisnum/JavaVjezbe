package projekatGame;

/**
 * Interfejs koji predstavlja geometrijski oblik koji može učestvovati u koliziji.
 * Implementacije drže svoju poziciju (x,y) i dimenzije/parametre oblika.
 */
public interface Collidable {
    /**
     * Postavi poziciju kolajdera (obično zove GameObject kada se pozicija promijeni).
     * @param x x-koordinata (interpretacija zavisi od implementacije)
     * @param y y-koordinata
     */
    void setPosition(int x, int y);

    /**
     * Dohvati x-koordinatu kolajdera (interpretacija: za Rectangle -> top-left x; za Circle -> center x).
     */
    int getX();

    /**
     * Dohvati y-koordinatu kolajdera.
     */
    int getY();

    /**
     * Provjerava sudar između ovog kolajdera i drugog kolajdera. Implementacija treba
     * poznavati svoju interpretaciju pozicije (rect: top-left, circle: center).
     *
     * @param other drugi kolajder
     * @return true ako se oblici sijeku
     */
    boolean intersects(Collidable other);
}
